q2-s2
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using dotnetapp.Data;
using dotnetapp.Models;

namespace dotnetapp.Controllers
{

    public class CustomerController : Controller
    {

        private readonly ApplicationDbContext _dbContext;

        public CustomerController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // GET: Customer/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Customer customer)
        {
            if (ModelState.IsValid)
            {
                _dbContext.Customers.Add(customer);
                _dbContext.SaveChanges();
                return RedirectToAction("Success");
            }
            return View(customer);
        }

        public IActionResult Success()
        {
            ViewBag.Message = "Customer created successfully";
            return View();
        }
    }
}


----------------

using dotnetapp.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Data
{

    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
         { 
            
         }

        public DbSet<Customer> Customers { get; set; }
    }
}

=------------------
using System;
using System.ComponentModel.DataAnnotations;
namespace dotnetapp.Models
{

    public class Customer
    {
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "First name is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [UniqueEmail(ErrorMessage = "Email must be unique")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Invalid phone number format")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "The value is invalid")]
        [MinAge(18, ErrorMessage = "Customer must be 18 years or older")]
        [DataType(DataType.Date)]
        public DateTime BirthDate { get; set; }

        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; }
    }

}

-----------------------
using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using dotnetapp.Data;


namespace dotnetapp.Models
{
    public class MinAgeAttribute : ValidationAttribute
    {
        
        private readonly int _minAge;

        public MinAgeAttribute(int minAge)
        {
            _minAge = minAge;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is DateTime birthDate)
            {
                var age = DateTime.Now.Year - birthDate.Year;
                if (birthDate > DateTime.Now.AddYears(-age)) age--;
                if (age >= _minAge)
                    return ValidationResult.Success;
            }
            return new ValidationResult(ErrorMessage ?? $"Age must be at least {_minAge} years");
        }
    }

    public class UniqueEmailAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var dbContext = (ApplicationDbContext)validationContext.GetService(typeof(ApplicationDbContext));
            if(dbContext == null){
                return new ValidationResult(ErrorMessage ?? "db is null");
            }

            var email = value?.ToString();

            if (dbContext.Customers.Any(c => c.Email == email))
            {
                return new ValidationResult(ErrorMessage ?? "Email already exists");
            }

            return ValidationResult.Success;
        }
    }
}
--------------------------------------
@model dotnetapp.Models.Customer

<h2>Create Customer</h2>
<form asp-action="Create" method="post">
    <div>
        <label asp-for="FirstName"></label>
        <input asp-for="FirstName" />
        <span asp-validation-for="FirstName" class="text-danger"></span>
    </div>
    <div>
        <label asp-for="LastName"></label>
        <input asp-for="LastName" />
        <span asp-validation-for="LastName" class="text-danger"></span>
    </div>
    <div>
        <label asp-for="Email"></label>
        <input asp-for="Email" />
        <span asp-validation-for="Email" class="text-danger"></span>
    </div>
    <div>
        <label asp-for="PhoneNumber"></label>
        <input asp-for="PhoneNumber" />
        <span asp-validation-for="PhoneNumber" class="text-danger"></span>
    </div>
    <div>
        <label asp-for="BirthDate"></label>
        <input asp-for="BirthDate" type="date" />
        <span asp-validation-for="BirthDate" class="text-danger"></span>
    </div>
    <div>
        <label asp-for="Address"></label>
        <input asp-for="Address" />
        <span asp-validation-for="Address" class="text-danger"></span>
    </div>
    <button type="submit">Submit</button>
</form>
--------------------------------------------------

<h2>@ViewBag.Message</h2>
---------------------
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>@ViewData["Title"] - dotnetapp</title>
    <link rel="stylesheet" href="~/lib/bootstrap/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="~/css/site.css" asp-append-version="true" />
    <link rel="stylesheet" href="~/dotnetapp.styles.css" asp-append-version="true" />
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-light bg-white border-bottom box-shadow mb-3">
            <div class="container-fluid">
                <a class="navbar-brand" asp-area="" asp-controller="Home" asp-action="Index">dotnetapp</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                    <ul class="navbar-nav flex-grow-1">
                        <li class="nav-item">
                            <a class="nav-link text-dark" asp-area="" asp-controller="Home" asp-action="Index">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" asp-area="" asp-controller="Home" asp-action="Privacy">Privacy</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="container">
        <main role="main" class="pb-3">
            @RenderBody()
        </main>
    </div>

    <footer class="border-top footer text-muted">
        <div class="container">
            &copy; 2023 - dotnetapp - <a asp-area="" asp-controller="Home" asp-action="Privacy">Privacy</a>
        </div>
    </footer>
    <script src="~/lib/jquery/dist/jquery.min.js"></script>
    <script src="~/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="~/js/site.js" asp-append-version="true"></script>
    @await RenderSectionAsync("Scripts", required: false)
</body>
</html>
